tree-sitter grammar for hare. decently well maintained but may still be out of
date relative to current hare - if that's the case, feel free to poke me at
<ecs@d2evs.net> and i'll fix it
